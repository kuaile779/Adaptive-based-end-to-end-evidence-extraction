# -*- coding: utf-8 -*-

import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoModel
from torch.nn import CrossEntropyLoss, BCELoss

class c3filter(nn.Module):
    def __init__(self, model_type):
        super().__init__()
        self.encoder = AutoModel.from_pretrained(model_type)
        self.n_hidden = self.encoder.config.hidden_size
        self.raw_prediction = nn.Linear(self.n_hidden, 1)

        # self.get_atten = nn.Linear(self.n_hidden, 1)
        # self.prediction = nn.Linear(self.n_hidden, 1)

        self.temp = 0.5

        self.nmd = 0.4

    def reparameterize(self, z, eps: float = 1e-7):
        """
        Gumbel-softmax trick to sample from Categorical Distribution
        :param z: (Tensor) Latent Codes [B x D x K]
        :return: (Tensor) [B x D]
        """
        # Sample from Gumbel
        u = torch.rand_like(z)
        g = - torch.log(- torch.log(u + eps) + eps)

        # Gumbel-Softmax sample
        s = F.softmax((z + g) / self.temp, dim=-1)
        return s

    def full_mask(self, atten, filter_mask, tokenizer):
        atten1 = atten.tolist()
        top_index = [atten1.index(e) for e in atten1 if e >= self.nmd]
        if len(top_index) == 0:
            top_index = [atten1.index(max(atten1))]

        fin_index = []
        for ii in top_index:
            fin_index.extend(filter_mask[2][ii])
        fin_index = list(set(fin_index))
        fin_index.sort(reverse=False)  # 列表去重后升序排序

        all_input_ids = []  # 4 * 512
        all_attention_mask = []  # 4 * 512
        all_token_type_ids = []  # 4 * 512
        for j in range(4):
            encoded_dict = tokenizer.encode_plus(
                "".join([filter_mask[1][index] for index in fin_index]),
                filter_mask[0][j],
                max_length=512,
                return_overflowing_tokens=True,
                padding="max_length",
                truncation="only_second",
                return_token_type_ids=True
            )
            assert encoded_dict["overflowing_tokens"] == []

            all_input_ids.append(encoded_dict['input_ids'])
            all_attention_mask.append(encoded_dict['attention_mask'])
            all_token_type_ids.append(encoded_dict['token_type_ids'])

        a = torch.LongTensor(all_input_ids).cuda()  # 4 * 512
        b = torch.LongTensor(all_attention_mask).cuda()
        c = torch.LongTensor(all_token_type_ids).cuda()
        return a, b, c

    def forward(self,
                input_ids=None,
                attention_mask=None,
                token_type_ids=None,
                filter_input_ids=None,
                filter_attention_mask=None,  # num * 4 * l
                filter_token_type_ids=None,
                filter_mask=None,  # 4 * num * l
                label=None,
                k=None,
                tokenizer=None,
                ):
        # 4 * l * h
        raw_hidden = self.encoder(input_ids,
                                    attention_mask=attention_mask,
                                    token_type_ids=token_type_ids)[0]
        raw_hidden = raw_hidden.select(1, 0)  # 4 * h
        raw_hidden = self.raw_prediction(raw_hidden).squeeze(-1) # 4

        if label is None:
            return raw_hidden
        # filter
        filter_hidden = self.encoder(filter_input_ids,
                                     attention_mask=filter_attention_mask,
                                     token_type_ids=filter_token_type_ids)[0]  # num * l * h

        atten = self.raw_prediction(filter_hidden.select(1, 0)).squeeze(-1)  # num
        atten = self.reparameterize(atten)

        if tokenizer is None:
            return atten

        a, b, c = self.full_mask(atten, filter_mask, tokenizer)  # 4 * h
        new_hidden = self.encoder(a, attention_mask=b, token_type_ids=c)[0]
        new_hidden = new_hidden.select(1, 0)  # 4 * h
        new_hidden = self.raw_prediction(new_hidden).squeeze(-1) # 4
        #
        loss1 = F.cross_entropy(raw_hidden.unsqueeze(0), label)
        loss2 = F.cross_entropy(new_hidden.unsqueeze(0), label)

        total_loss = loss1 + 0.1 * loss2
        return total_loss
