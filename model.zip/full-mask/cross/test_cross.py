# -*- coding: utf-8 -*-

import argparse
import torch, pickle, json
from tqdm import tqdm
from model_cross import c3filter
from data_process_cross import c3Feature
from transformers import logging as lg
lg.set_verbosity_error()

def to_list(tensor):
    return tensor.detach().cpu().tolist()

def dump_file(obj, filename):
    f = open(filename, 'wb')
    pickle.dump(obj, f)

def load_file(filename):
    with open(filename, 'rb') as f:
        data = pickle.load(f)
    return data

parser = argparse.ArgumentParser()
parser.add_argument("--model_type", type=str, default='../../model')
parser.add_argument("--batch_size", type=int, default=1)

args = parser.parse_args()
model_type = args.model_type
batch_size = args.batch_size

model = c3filter(model_type)
model.load_state_dict(torch.load('checkpoint-cross.th', map_location='cpu'))
model.cuda()

def eval_in_raw_train_data(raw_train_data_filename="../data/train-cross.obj", output="../output/raw-cross-res.json"):

    test_data = load_file(raw_train_data_filename)
    model.eval()
    total = len(test_data)
    right = 0
    all_res = {}
    with torch.no_grad():
        for i in tqdm(range(0, total, batch_size)):

            id = test_data[i].id
            input_ids = test_data[i].input_ids
            attention_mask = test_data[i].attention_mask
            token_type_ids = test_data[i].token_type_ids
            filter_input_ids = test_data[i].filter_input_ids
            filter_attention_mask = test_data[i].filter_attention_mask
            filter_token_type_ids = test_data[i].filter_token_type_ids
            filter_mask = test_data[i].filter_mask
            label = test_data[i].label

            input_ids = torch.LongTensor(input_ids).cuda()  # 4 * 512
            attention_mask = torch.LongTensor(attention_mask).cuda()
            token_type_ids = torch.LongTensor(token_type_ids).cuda()

            filter_input_ids = torch.LongTensor(filter_input_ids).cuda()  # num * 4 * 512
            filter_attention_mask = torch.LongTensor(filter_attention_mask).cuda()
            filter_token_type_ids = torch.LongTensor(filter_token_type_ids).cuda()

            label = torch.LongTensor([label]).cuda()

            inputs = {
                "input_ids": input_ids,
                "attention_mask": attention_mask,
                "token_type_ids": token_type_ids,
                "filter_input_ids": filter_input_ids,
                "filter_attention_mask": filter_attention_mask,
                "filter_token_type_ids": filter_token_type_ids,
                "filter_mask": filter_mask,
                "label": label,
            }

            atten = model(**inputs)
            atten = to_list(atten)
            all_res[id] = atten

    with open(output, "w", encoding='utf-8') as f:
        json.dump(all_res, f, ensure_ascii=False)

print("Start eval in raw data!")
eval_in_raw_train_data()
print("End eval in raw data!")

