# -*- coding: utf-8 -*-

import argparse
import torch

from model_cross import c3filter
from data_process_cross import *
import torch.distributed as dist
from transformers import logging as lg
lg.set_verbosity_error()
import numpy as np

torch.manual_seed(10)
np.random.seed(10)

parser = argparse.ArgumentParser()
parser.add_argument("--batch_size", type=int, default=1)
parser.add_argument(
        "--gradient_accumulation_steps",
        type=int,
        default=32,
        help="Number of updates steps to accumulate before performing a backward/update pass.",
    )
parser.add_argument("--logging_steps", type=int, default=100, help="Log every X updates steps.")
parser.add_argument("--epoch", type=int, default=10)
parser.add_argument("--lr", type=float, default=3.0e-5)
parser.add_argument("--max_grad_norm", type=float, default=1)
parser.add_argument("--model_type", type=str, default="../../model")

args = parser.parse_args()
print(json.dumps(vars(args), sort_keys=False, indent=2))
model_type = args.model_type

data = load_file('../data/train-cross.obj')
valid_data = load_file('../data/test.obj')
batch_size = args.batch_size
tokenizer = BertTokenizer.from_pretrained(model_type)
model = c3filter(model_type).cuda()
optimizer = torch.optim.AdamW(model.parameters(),
                              weight_decay=0.01,
                              lr=args.lr)

def get_shuffle_data():
    np.random.shuffle(data)
    return data

def to_list(tensor):
    return tensor.detach().cpu().tolist()

def iter_printer(total, epoch):
    return tqdm(range(0, total, batch_size), desc='epoch {}'.format(epoch))

def train(epoch):
    train_data = get_shuffle_data()
    total = len(train_data)
    step = -1
    for i in iter_printer(total, epoch):
        model.train()
        step += 1
        input_ids = train_data[i].input_ids
        attention_mask = train_data[i].attention_mask
        token_type_ids = train_data[i].token_type_ids
        filter_input_ids = train_data[i].filter_input_ids
        filter_attention_mask = train_data[i].filter_attention_mask
        filter_token_type_ids = train_data[i].filter_token_type_ids
        filter_mask = train_data[i].filter_mask
        label = train_data[i].label

        input_ids = torch.LongTensor(input_ids).cuda() # 4 * 512
        attention_mask = torch.LongTensor(attention_mask).cuda()
        token_type_ids = torch.LongTensor(token_type_ids).cuda()

        filter_input_ids = torch.LongTensor(filter_input_ids).cuda()  # num * 512
        filter_attention_mask = torch.LongTensor(filter_attention_mask).cuda()
        filter_token_type_ids = torch.LongTensor(filter_token_type_ids).cuda()

        label = torch.LongTensor([label]).cuda()

        inputs = {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
            "token_type_ids": token_type_ids,
            "filter_input_ids": filter_input_ids,
            "filter_attention_mask": filter_attention_mask,
            "filter_token_type_ids": filter_token_type_ids,
            "filter_mask": filter_mask,
            "label": label,
            "k": k,
            "tokenizer": tokenizer,
        }

        loss = model(**inputs)
        if args.gradient_accumulation_steps > 1:
            loss = loss / args.gradient_accumulation_steps
        loss.backward()
        global logging_loss
        logging_loss += loss.item()

        if (step + 1) % args.gradient_accumulation_steps == 0:

            torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
            optimizer.step()
            optimizer.zero_grad()

            # if args.logging_steps > 0 and global_step % args.logging_steps == 0:
            #     print(f"Current global step: {global_step}")
            #     print(f"average loss of batch: {logging_loss / args.logging_steps}")
            #     logging_loss = 0

def evaluation(epoch):
    model.eval()
    total = len(valid_data)
    res = {}
    res_label = {}
    with torch.no_grad():
        for i in iter_printer(total, epoch):
            id = valid_data[i].id
            input_ids = valid_data[i].input_ids
            attention_mask = valid_data[i].attention_mask
            token_type_ids = valid_data[i].token_type_ids
            label = valid_data[i].label

            input_ids = torch.LongTensor(input_ids).cuda()  # 4 * 512
            attention_mask = torch.LongTensor(attention_mask).cuda()
            token_type_ids = torch.LongTensor(token_type_ids).cuda()

            inputs = {
                "input_ids": input_ids,
                "attention_mask": attention_mask,
                "token_type_ids": token_type_ids,
            }
            predictions = model(**inputs)
            predictions = to_list(predictions)
            if id not in res.keys():
                res[id] = predictions
            else:
                res[id] = [max(res[id][k], predictions[k])  for k in range(4)]
            res_label[id] = label
    right = 0
    ttol = len(res)
    for id in res.keys():
        index = res[id].index(max(res[id]))
        lab = res_label[id]
        if index == lab:
            right += 1
    acc = 100 * right / ttol
    print('epoch {} eval acc is {}'.format(epoch, acc))
    return acc

logging_loss = 0.0
global_step = 0
best_acc = 0.0
k = 0.01

t_total = len(data) // batch_size // args.gradient_accumulation_steps * args.epoch
print(" Total optimization steps = ", t_total)
for epo in range(args.epoch):
    print("----------")
    train(epo)
    accuracy = evaluation(epo)
    if accuracy > best_acc:
        best_acc = accuracy
        with open('checkpoint-cross.th', 'wb') as f:
            state_dict = model.state_dict()
            torch.save(state_dict, f)
    # k = min(0.1, k+0.1)
print("best acc:", best_acc)