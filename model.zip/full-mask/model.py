# -*- coding: utf-8 -*-

import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoModel
from torch.nn import CrossEntropyLoss, BCELoss

class c3filter(nn.Module):
    def __init__(self, model_type):
        super().__init__()
        self.encoder = AutoModel.from_pretrained(model_type)
        self.n_hidden = self.encoder.config.hidden_size
        self.raw_prediction = nn.Linear(self.n_hidden, 1)

        # self.get_atten = nn.Linear(self.n_hidden, 1)
        # self.prediction = nn.Linear(self.n_hidden, 1)

    def forward(self,
                input_ids=None,
                attention_mask=None,
                token_type_ids=None,
                filter_input_ids=None,
                filter_attention_mask=None,  # num * 4 * l
                filter_token_type_ids=None,
                filter_mask=None,  # 4 * num * l
                label=None,
                k=None,
                tokenizer=None,
                ):
        # 4 * l * h
        raw_hidden = self.encoder(input_ids,
                                    attention_mask=attention_mask,
                                    token_type_ids=token_type_ids)[0]
        raw_hidden = raw_hidden.select(1, 0)  # 4 * h
        raw_hidden = self.raw_prediction(raw_hidden).squeeze(-1) # 4

        if label is None:
            return raw_hidden
        #
        loss1 = F.cross_entropy(raw_hidden.unsqueeze(0), label)

        return loss1
