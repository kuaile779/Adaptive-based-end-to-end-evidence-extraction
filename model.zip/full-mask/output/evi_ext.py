import json

ext_evi_num = 2

with open("../../data/process/final-train.json", encoding='utf-8') as f:
    data = json.load(f)["data"]

with open("./raw-res.json", encoding='utf-8') as f:
    evi_res = json.load(f)

id2exam = {}
for pre in data:
    id2exam[pre["id"]] = pre

assert len(id2exam) == len(evi_res)

for k in id2exam.keys():
    tres = []
    for i in range(len(evi_res[k])):
        tres.append([i, evi_res[k][i]])
    tres = sorted(tres, key=lambda x: x[1], reverse=True)
    id2exam[k]["evidence"] = []
    for e in tres:
        if e[1] >= 0.3:
            evi_num = e[0]
            id2exam[k]["evidence"].append([evi_num, id2exam[k]["filter_context"][evi_num]])
    if len(id2exam[k]["evidence"]) == 0:
        evi_num = tres[0][0]
        id2exam[k]["evidence"].append([evi_num, id2exam[k]["filter_context"][evi_num]])

new_data = {
    "version": "new-train",
    "data": [],
}
for k in id2exam.keys():
    new_data["data"].append(id2exam[k])

with open("new-train.json", "w", encoding='utf-8') as f:
    json.dump(new_data, f, indent=2, ensure_ascii=False)