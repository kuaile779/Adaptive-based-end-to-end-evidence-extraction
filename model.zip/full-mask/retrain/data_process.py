# -*- coding: utf-8 -*-

import json, math
import random
import logging
import collections
from transformers import BasicTokenizer
from dataclasses import dataclass
from typing import List, Dict
from transformers import BertTokenizer
from torch.utils.data import Dataset, TensorDataset
import os, pickle
from tqdm import tqdm
from torch.utils.data import Dataset
from transformers.tokenization_utils import _is_whitespace, _is_punctuation, _is_control

tokenizer = None

@dataclass
class c3Feature:
    id: str
    input_ids: List
    attention_mask: List
    token_type_ids: List
    label: int = None

def dump_file(obj, filename):
    f = open(filename, 'wb')
    pickle.dump(obj, f)

def load_file(filename):
    with open(filename, 'rb') as f:
        data = pickle.load(f)
    return data

answers_map = ["A", "B", "C", "D"]
def convert_single_example_to_features(example, max_seq_length=512, max_query_length=64, max_answer_length=40):
    id = example['id']
    pid = example['pid']
    options = example['options']
    question = example['question']

    answer = example['answer']
    label = answers_map.index(answer)

    if len(options) != 4:
        for k in range(4 - len(options)):
            options.append("")

    qa_list = []
    for j in range(len(options)):
        option = options[j]
        if "_" in question:
            qa_cat = question.replace("_", option)
        else:
            qa_cat = " ".join([question, option])
        qa_list.append(qa_cat)
    assert len(qa_list) == 4

    max_qa_length = max_answer_length + max_query_length
    for j in range(4):
        temp = tokenizer.tokenize(qa_list[j])
        if len(temp) > max_qa_length:
            temp = temp[- max_qa_length:]
        qa_list[j] = temp

    # print(qa_list[label])

    # filter
    evidence = example["evidence"]
    evidence = sorted(evidence, key=lambda x: x[0], reverse=False)
    context_tokens = []
    for temp in evidence:
        temp_context_tokens = tokenizer.tokenize(temp[1])
        context_tokens.extend(temp_context_tokens)
    # raw ids
    all_input_ids = []  # 4 * 512
    all_attention_mask = []  # 4 * 512
    all_token_type_ids = []  # 4 * 512
    for j in range(4):
        encoded_dict = tokenizer.encode_plus(
            context_tokens,
            qa_list[j],
            max_length=max_seq_length,
            return_overflowing_tokens=True,
            padding="max_length",
            truncation="only_second",
            return_token_type_ids=True
        )
        assert encoded_dict["overflowing_tokens"] == []

        input_ids = encoded_dict['input_ids']
        attention_mask = encoded_dict['attention_mask']
        token_type_ids = encoded_dict['token_type_ids']

        all_input_ids.append(input_ids)
        all_attention_mask.append(attention_mask)
        all_token_type_ids.append(token_type_ids)

    return c3Feature(
        id=id,
        input_ids=all_input_ids,
        attention_mask=all_attention_mask,
        token_type_ids=all_token_type_ids,
        label=label,
    )

def convert_to_features(filename):

    with open(filename, encoding='utf-8') as f:
        raw = json.load(f)
        data = raw['data']
        feature_list = []
        for example in tqdm(data):
            feature = convert_single_example_to_features(example)
            feature_list.append(feature)

    print('get {} with {} features'.format(filename, len(feature_list)))
    return feature_list

# 用原baseline方法分词
SPIECE_UNDERLINE = '▁'
def get_doc_token_in_expmrc(context_text):

    def is_whitespace(c):
      if c == " " or c == "\t" or c == "\r" or c == "\n" or ord(c) == 0x202F or c == SPIECE_UNDERLINE:
        return True
      return False

    def _is_chinese_char(cp):
      if ((cp >= 0x4E00 and cp <= 0x9FFF) or  #
                (cp >= 0x3400 and cp <= 0x4DBF) or  #
                (cp >= 0x20000 and cp <= 0x2A6DF) or  #
                (cp >= 0x2A700 and cp <= 0x2B73F) or  #
                (cp >= 0x2B740 and cp <= 0x2B81F) or  #
                (cp >= 0x2B820 and cp <= 0x2CEAF) or
                (cp >= 0xF900 and cp <= 0xFAFF) or  #
                (cp >= 0x2F800 and cp <= 0x2FA1F)):  #
        return True
      return False

    def is_fuhao(c):
      if c == '。' or c == '，' or c == '！' or c == '？' or c == '；' or c == '、' or c == '：' or c == '（' or c == '）' \
                or c == '－' or c == '~' or c == '「' or c == '《' or c == '》' or c == ',' or c == '」' or c == '"' or c == '“' or c == '”' \
                or c == '$' or c == '『' or c == '』' or c == '—' or c == ';' or c == '。' or c == '(' or c == ')' or c == '-' or c == '～' or c == '。' \
                or c == '‘' or c == '’':
        return True
      return False

    def _tokenize_chinese_chars(text):
      """Adds whitespace around any CJK character."""
      output = []
      for char in text:
        cp = ord(char)
        if _is_chinese_char(cp) or is_fuhao(char):
          if len(output) > 0 and output[-1] != SPIECE_UNDERLINE:
            output.append(SPIECE_UNDERLINE)
          output.append(char)
          output.append(SPIECE_UNDERLINE)
        else:
          output.append(char)
      return "".join(output)

    context_iter = _tokenize_chinese_chars(context_text)

    doc_tokens = []
    char_to_word_offset = []
    prev_is_whitespace = True
    for c in context_iter:
        if is_whitespace(c):
            prev_is_whitespace = True
        else:
            if prev_is_whitespace:
                doc_tokens.append(c)
            else:
                doc_tokens[-1] += c
            prev_is_whitespace = False
        if c != SPIECE_UNDERLINE:
            char_to_word_offset.append(len(doc_tokens) - 1)
    return doc_tokens, char_to_word_offset

def convert_dev_single_example_to_features(example, max_seq_length=512,
                                       max_query_length=64, max_answer_length=40, doc_stride=128):

    def get_split_text(text, split_len, doc_stride):
        split_text = []
        window = doc_stride
        w = 0
        while w * window + split_len < len(text):
            text_piece = text[w * window: w * window + split_len]
            w += 1
            split_text.append(text_piece)
        if text[w * window:]:
            split_text.append(text[w * window:])
        return split_text


    id = example['id']
    pid = example['pid']
    context = "".join(example['context'])
    options = example['options']
    question = example['question']
    answer = example['answer']
    label = answers_map.index(answer)

    # doc_token
    doc_tokens, char_to_word_offset = get_doc_token_in_expmrc(context)

    tok_to_orig_index = []
    orig_to_tok_index = []
    all_doc_tokens = []
    for (i, token) in enumerate(doc_tokens):
        orig_to_tok_index.append(len(all_doc_tokens))
        sub_tokens = tokenizer.tokenize(token)
        for sub_token in sub_tokens:
            tok_to_orig_index.append(i)
            all_doc_tokens.append(sub_token)
    assert len(orig_to_tok_index) == len(doc_tokens)
    assert len(tok_to_orig_index) == len(all_doc_tokens)

    qa_list = []
    if len(options) != 4:
        for k in range(4 - len(options)):
            options.append("")

    for j in range(len(options)):
        option = options[j]
        if "_" in question:
            qa_cat = question.replace("_", option)
        else:
            qa_cat = " ".join([question, option])
        qa_list.append(qa_cat)

    assert len(qa_list) == 4
    max_qa_length = max_answer_length + max_query_length
    for j in range(4):
        temp = tokenizer.tokenize(qa_list[j])
        if len(temp) > max_qa_length:
            temp = temp[- max_qa_length:]
        qa_list[j] = temp

    # 训练集长度大于512删去 测试集截取文章
    max_qa_len = 0
    for j in range(4):
        qa_len = len(qa_list[j])
        if qa_len > max_qa_len:
            max_qa_len = qa_len

    split_len = max_seq_length - max_qa_len - 3
    p_span = get_split_text(all_doc_tokens, split_len, doc_stride)

    all_features = []
    for p in p_span:

        # [cls] p [sep] q o [sep]
        all_input_ids = []  # 4 * 512
        all_token_type_ids = []  # 4 * 512
        all_attention_mask = []  # 4 * 512
        for j in range(4):

            encoded_dict = tokenizer.encode_plus(
                p,
                qa_list[j],
                max_length=max_seq_length,
                return_overflowing_tokens=True,
                padding="max_length",
                truncation="only_second",
                return_token_type_ids=True
            )
            assert encoded_dict["overflowing_tokens"] == []

            input_ids = encoded_dict['input_ids']
            attention_mask = encoded_dict['attention_mask']
            token_type_ids = encoded_dict['token_type_ids']

            all_input_ids.append(input_ids)
            all_attention_mask.append(attention_mask)
            all_token_type_ids.append(token_type_ids)

        all_features.append(c3Feature(
            id=id,
            input_ids=all_input_ids,
            attention_mask=all_attention_mask,
            token_type_ids=all_token_type_ids,
            label=label
        ))

    return all_features

def convert_dev_to_features(filename):

    with open(filename, encoding='utf-8') as f:
        raw = json.load(f)
        data = raw['data']
        feature_list = []
        for example in tqdm(data):
            # print("--------")
            feature = convert_dev_single_example_to_features(example)
            feature_list.extend(feature)

    print('get {} with {} features'.format(filename, len(feature_list)))
    return feature_list

def prepare_bert_data(model_type='../../model'):
    global tokenizer
    tokenizer = BertTokenizer.from_pretrained(model_type)
    if not os.path.exists('./data/train.obj'):
        train_data = convert_to_features('../output/new-train.json')
        dump_file(train_data, './data/train.obj')

    if not os.path.exists('./data/test.obj'):
        dev_data = convert_dev_to_features('../../data/process/c3-dev.json')
        dump_file(dev_data, './data/test.obj')
#
prepare_bert_data()  # 10068 / 794

