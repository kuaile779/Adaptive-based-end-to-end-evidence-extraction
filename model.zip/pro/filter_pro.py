
import json

filter_lv = 6  # 句子数大于5进行缩句

with open("../data/process/c3-train.json", encoding='utf-8') as f:
    data = json.load(f)["data"]

new_data = {"version": "train",
            "data": []}
for pre in data:
    context = pre["context"]
    filter_context = []
    if len(context) > filter_lv:
        joint_num = int(len(context) / filter_lv) + 1
        start = 0
        while start < len(context):
            filter_context.append("".join(context[start: start + joint_num]))
            start += joint_num
    else:
        filter_context = context[:]
    pre["filter_context"] = filter_context
    new_data["data"].append(pre)

with open("../data/process/final-train6.json", "w", encoding='utf-8') as f:
    json.dump(new_data, f, indent=2, ensure_ascii=False)
