
import json

filter_lv = 5  # 句子数大于5进行缩句
cross = 1

with open("../data/process/c3-train.json", encoding='utf-8') as f:
    data = json.load(f)["data"]

new_data = {"version": "train",
            "data": []}
for pre in data:
    context = pre["context"]
    filter_context = []
    if len(context) > filter_lv:
        joint_num = int(len(context) / filter_lv) + 1
        start = 0
        while start < len(context):
            filter_context.append(["".join(context[max(0,start- cross): start + joint_num]),
                                   [e for e in range(max(0,start-cross),min(len(context),start + joint_num))]
                                   ])
            start += joint_num
    else:
        for i in range(len(context)):
            filter_context.append([
                context[i],
                [i]
            ])
    pre["filter_context"] = filter_context
    new_data["data"].append(pre)

with open("../data/process/final-cross-train.json", "w", encoding='utf-8') as f:
    json.dump(new_data, f, indent=2, ensure_ascii=False)
